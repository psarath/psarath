package com.payroll.serviceImpl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payroll.dao.ProvidentFundDao;
import com.payroll.entity.ProvidentFund;
import com.payroll.service.ProvidentFundService;

@Service
public class ProvidentFundServiceimpl implements ProvidentFundService {
	
	@Autowired
	private ProvidentFundDao providentFundDao;

	@Override
	public void storeProvidentFund(ProvidentFund providentFund) {
		// TODO Auto-generated method stub
		providentFundDao.storeProvidentFund(providentFund);
		
	}

}
