package com.payroll.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payroll.dao.EmployeeDao;
import com.payroll.entity.Employee;
import com.payroll.service.EmployeeService;

@Service
public class EmployeeServiceimpl implements EmployeeService{

	@Autowired 
	private EmployeeDao employeeDao;
	
	/**
	 * @author Teja
	 * @since 1-9-2016
	 * @version 1
	 * 
	 * this method is used to storeEmployee in employee table
	 * 
	 * @return void
	 * @throws null pointer 
	 * 
	 */
	
	@Override
	public void storeEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeDao.storeEmployee(employee);
		
	}
	
	@Override
	public List<Employee> getAllEmployeeList() {
		return employeeDao.getAllEmployeeList();
	}

	@Override
	public List<Employee> getAllEmployeeListWithOffset(String offset) {
		return employeeDao.getAllEmployeeListWithOffset(offset);
	}
	
	@override
	public Employee getEmployeeByEmployeeId(Long employeeId) {
		return employeeDao.getEmployeeByEmployeeId(employeeId);
		
		
	}

	@Override
	public List<Employee> getemployeeListByBusinessUnitID(Long businessUnitID) {
		return employeeDao.getemployeeListByBusinessUnitID(businessUnitID);
	}

	 
	
	
}
