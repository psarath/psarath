package com.payroll.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payroll.dao.PayrollDao;
import com.payroll.entity.Payroll;
import com.payroll.service.PayrollService;

@Service
public class PayrollServiceImpl implements PayrollService {
	
	@Autowired
	private PayrollDao payrollDao;
	

	@Override
	public List<Payroll> getAllpayroll() {
		
		
		List<Payroll>  payrollList = payrollDao.getAllPayroll();
		// TODO Auto-generated method stub
		return payrollList;
	}
	
	
	

}
