package com.payroll.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payroll.dao.BusinessUnitDao;
import com.payroll.entity.BusinessUnit;
import com.payroll.service.BusinessUnitService;

@Service
public class BusinessUnitServiceImpl implements BusinessUnitService{

	@Autowired
	BusinessUnitDao businessUnitDao;
	
	@Override
	public List<BusinessUnit> getAllbusinessUnit() {
		
		List<BusinessUnit>  businessUnitList = businessUnitDao.getAllbusinessUnit();
		// TODO Auto-generated method stub
		return businessUnitList;
	}
	
	 
}
