package com.payroll.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.User;


@Controller  
public class LoginController {  
	
	
	@Autowired 
	private SessionFactory sessionFactory;   
	
    @RequestMapping("/Registration")  
    public ModelAndView Registration(@ModelAttribute User user) {  

	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("registration");
	       return m;  
    }  
    
    @Transactional
    @RequestMapping("/insert")  
    public ModelAndView insert(@ModelAttribute User user) {  
         
    	   Session s =  sessionFactory.getCurrentSession();
		   Transaction trans=s.beginTransaction();
		   s.save(user);
		   trans.commit();
		   
		   ModelAndView m = new ModelAndView();
	  	   m.setViewName("registration");
	       return m;  
    }  
    
     
 } 
