package com.payroll.controller;

import java.io.Writer;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.BusinessUnit;
import com.payroll.entity.Employee;
import com.payroll.service.EmployeeService;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;
import com.thoughtworks.xstream.io.json.JsonWriter;


@Controller  
public class DashboardController {  
	
	
	@Autowired 
	private SessionFactory sessionFactory;   
	
	@Autowired
	private EmployeeService employeeService;
	
	 
	/**
	 * @author Teja
	 * @since 1/9/2016
	 * @version 1 
	 * 
	 * 
	 * this method is used to show the dashboard page
	 * 
	 * @return void
	 */
	
    @RequestMapping("/businessUnitEmployeeList")  
    public ModelAndView businessUnitEmployeeList(@ModelAttribute BusinessUnit businessUnit) {  

	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("businessUnitEmployeeList");
	       return m;  
    }  
    
    @RequestMapping(value = "/getemployeeListByBusinessUnitID" , method = RequestMethod.POST)
    public @ResponseBody String getemployeeListByBusinessUnitID(@RequestParam (value = "businessUnitID", required = false) Long businessUnitID) {
    	String resultJson = null;
    	
    	List<Employee> emp = employeeService.getemployeeListByBusinessUnitID(businessUnitID);
    	
    	resultJson = toJSON(emp);
    	return resultJson;
    }
    
    public String toJSON(Object obj){
	    XStream xstream = new XStream(new JsonHierarchicalStreamDriver() {
	        public HierarchicalStreamWriter createWriter(Writer writer) {
	            return new JsonWriter(writer, JsonWriter.DROP_ROOT_MODE);
	        }
	    });
	    return xstream.toXML(obj);
     }
    
    
}