package com.payroll.controller;

import java.io.Writer;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.BusinessUnit;
import com.payroll.service.BusinessUnitService;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;
import com.thoughtworks.xstream.io.json.JsonWriter;
@RestController  
public class BusinessUnitController {  
	
	
	@Autowired 
	private SessionFactory sessionFactory;   
	
	@Autowired
	private BusinessUnitService businessUnitService;
	
    @RequestMapping("/businessUnitList")  
    public ModelAndView Registration(@ModelAttribute BusinessUnit department) {  
    	
		   
		
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("businessunitList");
	       return m;  
    }  
    
    @RequestMapping(value = "/getbusinessUnitList", method = RequestMethod.POST)
    public @ResponseBody String businessUnitList() {  
    	   String resultJson = null;
    	   List<BusinessUnit>  businessUnitList = businessUnitService.getAllbusinessUnit();
    	   
    	   resultJson =  toJSON(businessUnitList);
		   return resultJson;
    }
    
    public String toJSON(Object obj){
        XStream xstream = new XStream(new JsonHierarchicalStreamDriver() {
            public HierarchicalStreamWriter createWriter(Writer writer) {
                return new JsonWriter(writer, JsonWriter.DROP_ROOT_MODE);
            }
        });
        return xstream.toXML(obj);
    }
    
    @RequestMapping(value = "/storeBusinessUnit" , method = RequestMethod.POST)     
    public ModelAndView store(@RequestParam(value = "json", required = false) String json,HttpServletRequest request) throws JSONException {  
         	
    		String jsonc = "{" + json + "}";
    		JSONObject jsonObj = new JSONObject(jsonc);
    		BusinessUnit businessUnit = new BusinessUnit();
    		
    		if (jsonObj.has("businessUnitName") && !(jsonObj.getString("businessUnitName").isEmpty())){
    			 businessUnit.setBusinessUnitName(jsonObj.getString("businessUnitName"));
 			}
    		
    		if (jsonObj.has("businessUnitRandomNumber") && !(jsonObj.getString("businessUnitRandomNumber").isEmpty())){
   			 businessUnit.setBusinessUnitRandomNumber(jsonObj.getString("businessUnitRandomNumber"));
			}
    		
    		if (jsonObj.has("description") && !(jsonObj.getString("description").isEmpty())){
    			businessUnit.setDescription(jsonObj.getString("description"));
   			}
    		
		
    	   Session s =  sessionFactory.getCurrentSession();
		   Transaction trans=s.beginTransaction();
		   s.save(businessUnit);
		   trans.commit();
		   
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("businessunit");
	       return m; 
    }  
     
}