package com.payroll.service;

import java.util.List;

import com.payroll.entity.BusinessUnit;

public interface BusinessUnitService {
	
	List<BusinessUnit> getAllbusinessUnit(); 
}
