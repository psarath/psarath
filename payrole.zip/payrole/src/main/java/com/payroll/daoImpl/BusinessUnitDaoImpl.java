package com.payroll.daoImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payroll.dao.BusinessUnitDao;
import com.payroll.entity.BusinessUnit;
@Repository
public class BusinessUnitDaoImpl implements BusinessUnitDao{
	

	@Autowired 
	private SessionFactory sessionFactory;   
	

	@Override
	public List<BusinessUnit> getAllbusinessUnit() {
		Session session = sessionFactory.getCurrentSession();
		Transaction trans1=session.beginTransaction();
		List<BusinessUnit> businessUnitList = session.createQuery("from BusinessUnit businessUnit").list();
		trans1.commit();
		return businessUnitList;
		
	}
	

}