package com.payroll.dao;

import java.util.List;

import com.payroll.entity.Payroll;

public interface PayrollDao {
	
	

	List<Payroll> getAllPayroll();

}
