package com.payroll.dao;

import java.util.List;

import com.payroll.entity.Employee;

public interface EmployeeDao {
			
	public void storeEmployee(Employee employee);
	
	public List<Employee> getAllEmployeeList();
	
	public List<Employee> getAllEmployeeListWithOffset(String offset);
	
	public Employee getEmployeeByEmployeeId(Long employeeId);
	
	public List<Employee> getemployeeListByBusinessUnitID(Long businessUnitID);
	
	
}
