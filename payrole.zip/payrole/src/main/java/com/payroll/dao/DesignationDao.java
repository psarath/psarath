package com.payroll.dao;

import java.util.List;

import com.payroll.entity.Designations;

public interface DesignationDao {
	
	List<Designations> getAllDesignations();

}
