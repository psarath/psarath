package uprr.ptc;

import java.awt.image.TileObserver;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReadExcel {
	
	public String readExcel(Date TodayDate) throws Exception {
		
	  //FOR SINGLE DATE	
      /*StatusByDate sd = new StatusByDate();
      List<GridModel> gridModels = sd.StatusByDate(TodayDate);*/
      
      //FOR MULTIPLE DATES
      StatusByMultipleDate sbm = new StatusByMultipleDate();
      
      UtilDates ud = new UtilDates();
      List<Date> al = ud.currentWeekDaysUpToCurrentDate();
      List<GridModel> gridModels = sbm.StatusByDate(al);
      
      String htmlText = "";
      
      
      
	  htmlText = htmlText +  (" <table style=\"border: 1px solid black;border-collapse: collapse;width: 100%;\">");
	  htmlText = htmlText +  (" <thead>");
	  htmlText = htmlText +  (" <tr>");
	  
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">Date</th>");
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">Day</th>");
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">Divya</th>");
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">HemaSudha</th>");
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">Ather</th>");
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">ManaSwini</th>");
	  htmlText = htmlText +  ("   <th width='100px;' style=\"border: 1px solid black;\">Ravi</th>");
	  
	  htmlText = htmlText +  (" </tr>");
	  htmlText = htmlText +  (" </thead>");
	  for(GridModel gm : gridModels){
		  
		  htmlText = htmlText +  (" <tr>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getDate()+"</td>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getDay()+"</td>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getDivya()+"</td>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getHemasudha()+"</td>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getAther()+"</td>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getManaswini()+"</td>");
		  htmlText = htmlText +  ("   <td width='100px;' style=\"border: 1px solid black;\">"+gm.getRavi()+"</td>");
		  
		  htmlText = htmlText +  (" </tr>");
	  }
	  htmlText = htmlText +  ("</table>");
	      
      
      
      /*htmlText = htmlText +  ("<table>");
      htmlText = htmlText +  (" <thead>");
      htmlText = htmlText +  ("<tr>");
      htmlText = htmlText +  ("<th>Name</th>");
      htmlText = htmlText +  ("<th>Status</th>");
      htmlText = htmlText +  ("</tr>");
      htmlText = htmlText +  (" </thead>");
      for(GridModel gm : gridModels){
    	  htmlText = htmlText +  ("<tr>");
    	  htmlText = htmlText +  ("<td>Divya</td>");
    	  htmlText = htmlText +  ("<td>"+gm.getDivya()+"</td>");
    	  htmlText = htmlText +  ("</tr>");
    	  
    	  htmlText = htmlText +  ("<tr>");
    	  htmlText = htmlText +  ("<td>HemaSudha</td>");
    	  htmlText = htmlText +  ("<td>"+gm.getHemasudha()+"</td>");
    	  htmlText = htmlText +  ("</tr>");
    	  
      }
      htmlText = htmlText +  ("  </table>");*/
	    
      return htmlText;
    }
}
