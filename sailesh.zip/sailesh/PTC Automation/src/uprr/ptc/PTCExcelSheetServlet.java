package uprr.ptc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Servlet implementation class PTCExcelSheetServlet
 */
@WebServlet("/PTCExcelSheetServlet")
public class PTCExcelSheetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PTCExcelSheetServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		List<String> valuesToUpdate = new ArrayList<String>();
		valuesToUpdate.add(request.getParameter("Id"));
		valuesToUpdate.add(request.getParameter("Date"));
		valuesToUpdate.add(request.getParameter("Day"));
		valuesToUpdate.add(request.getParameter("Divya"));
		valuesToUpdate.add(request.getParameter("Hemasudha"));
		valuesToUpdate.add(request.getParameter("Ather"));
		valuesToUpdate.add(request.getParameter("Manaswini"));
		valuesToUpdate.add(request.getParameter("Ravi"));

		writeExcel(valuesToUpdate);
	}
	public void writeExcel(List<String>valuesToUpdate) throws IOException {
	  try {
        FileInputStream inputStream = new FileInputStream(new File("C://Users//xsat015//Desktop//PTC.xlsx"));
        Workbook workbook = new XSSFWorkbook(inputStream);
 	    Sheet datatypeSheet = workbook.getSheetAt(0);
 	    int rowCount = datatypeSheet.getLastRowNum();
 	    Row existingRow = null;
 	    if(valuesToUpdate.get(0) != "") {
 	      existingRow = datatypeSheet.getRow((int) Double.parseDouble(valuesToUpdate.get(0)));	
 	    }
        if (existingRow != null) {
          Iterator<Cell> cellIterator = existingRow.iterator();
          while (cellIterator.hasNext()) {
            Cell currentCell = cellIterator.next();
            if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) {
            	currentCell.setCellValue(valuesToUpdate.get(currentCell.getColumnIndex()));
            } else if (currentCell.getCellType() == Cell.CELL_TYPE_NUMERIC && currentCell.getColumnIndex() != 1 ) {
            	currentCell.setCellValue(valuesToUpdate.get(currentCell.getColumnIndex()));
            } else if (currentCell.getColumnIndex() == 1 && currentCell.getDateCellValue() != null) {
            	currentCell.setCellValue(valuesToUpdate.get(currentCell.getColumnIndex()));
            }
           } 
        } else {
             Row row = datatypeSheet.createRow(++rowCount);
             int columnCount = 0;
             Cell cell = null;
             for (Object field : valuesToUpdate) {
               cell = row.createCell(columnCount);
               if (cell.getColumnIndex() ==0 && field == "") {
            	   field = rowCount;
               }
               if (field instanceof String) {
                 cell.setCellValue((String) field);
               } else if (field instanceof Integer) {
                   cell.setCellValue((Integer) field);
               }
               columnCount++;
              }
        }
        inputStream.close();

        FileOutputStream outputStream = new FileOutputStream("C://Users//xsat015//Desktop//PTC.xlsx");
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
             
     } catch (IOException | EncryptedDocumentException ex) {
       throw ex;
     }
		
	}
}
