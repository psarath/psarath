package uprr.ptc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class StatusByDate {
	
	
	public static void main(String args[]){
		
		
		StatusByDate(new Date());
		
	}
	
	public static List<GridModel>  StatusByDate (Date currentDate){
		
		 
		 List<GridModel> gridModels = new ArrayList<>();
		 List<String> excelHeaders = new ArrayList<String>();
		 String pattern = "yyyy-MM-dd";
     	 SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		 try {
           FileInputStream excelFile = new FileInputStream(new File("C://Users//xsat015//Desktop//PTC.xlsx"));
	       Workbook workbook = new XSSFWorkbook(excelFile);
	       Sheet datatypeSheet = workbook.getSheetAt(0);
	       Iterator<Row> iterator = datatypeSheet.iterator();
             while (iterator.hasNext()) {
         	   HashMap<String, String> ExcelData = new HashMap<String, String>();	 
               Row currentRow = iterator.next();
               Iterator<Cell> cellIterator = currentRow.iterator();
                while (cellIterator.hasNext()) {
               	 Cell currentCell = cellIterator.next();
                 if (currentRow.getRowNum() == 0) {
                	 excelHeaders.add(currentCell.getStringCellValue()); 
                 } else {
                	  
                	 
                	 if (DateUtil.isCellDateFormatted(currentRow.getCell(1)))
                	 {
                  	          SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                  	          String cellValue = sdf.format(currentRow.getCell(1).getDateCellValue());

	                  	     if(cellValue.equals(simpleDateFormat.format(currentDate))){
		                		   if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) {
		                           	ExcelData.put(excelHeaders.get(currentCell.getColumnIndex()).toLowerCase(),currentCell.getStringCellValue());
		                           } else if (currentCell.getCellType() == Cell.CELL_TYPE_NUMERIC && currentCell.getColumnIndex() != 1) {
		                           	ExcelData.put(excelHeaders.get(currentCell.getColumnIndex()).toLowerCase(),String.valueOf(currentCell.getNumericCellValue()));
		                           } else if (currentCell.getColumnIndex() == 1 && currentCell.getDateCellValue() != null) {
		                           	String date = simpleDateFormat.format(currentCell.getDateCellValue());
		                           	ExcelData.put(excelHeaders.get(currentCell.getColumnIndex()).toLowerCase(),date);
		                           }
	                  	     }
                	 }
                	 
                	   
                        
                    }	  
                  }
                if (!ExcelData.isEmpty())  {
                  GridModel gridModel = new GridModel(ExcelData);
                  gridModels.add(gridModel);
                }
                
             }
             workbook.close();
             excelFile.close();
	       } catch (FileNotFoundException e) {
	          e.printStackTrace();
	       } catch (IOException e) {
	          e.printStackTrace();
	       }
		return gridModels;

	}
	
}
