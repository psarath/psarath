package uprr.ptc;

import java.util.Date;
import java.util.Timer;

/**
 *
 * @author Dhinakaran P.
 */

//Main class
public class SchedulerMain {
	public static void main(String args[]) throws InterruptedException {

		Timer time = new Timer(); // Instantiate Timer Object
		SendEmail st = new SendEmail(); // Instantiate SheduledTask class
		 // Create Repetitively task for every 1 secs

		System.out.println("Execution in Main Thread....");
		
		
		
		
		

		Date date2pm = new java.util.Date();
		date2pm.setHours(17);
		date2pm.setMinutes(07);
		System.out.println("hai"+date2pm.getTime());
		
		Timer timer = new Timer();

	        
		//timer.schedule(st, date2pm.getTime());/*(st, 1000, 1000*5);   */
	        
		
		 
		
	}
}