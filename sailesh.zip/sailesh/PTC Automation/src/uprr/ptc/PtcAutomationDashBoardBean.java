package uprr.ptc;

public class PtcAutomationDashBoardBean {
	
	private String OnboardTestCases;
	
	
	
	/*private String TotalOBTestCases;
	private String TotalBOSTestCases;
	private String TotalSubdivisionTestCases;
	private String TotalOBAutomationTestCases;
	private String TotalBOSAutomationTestCases;
	private String TotalSubDivAutomationTestCases;
	private String OBManual;
	private String BOSManual; 
	private String SubDivManual; 
	private String TotalOBSupportsAutomated;
	private String TotalBOSSupportsAutomated;
	private String TotalSubDivSupportsAutomated;
	public String getTotalOBTestCases() {
		return TotalOBTestCases;
	}
	public void setTotalOBTestCases(String totalOBTestCases) {
		TotalOBTestCases = totalOBTestCases;
	}
	public String getTotalBOSTestCases() {
		return TotalBOSTestCases;
	}
	public void setTotalBOSTestCases(String totalBOSTestCases) {
		TotalBOSTestCases = totalBOSTestCases;
	}
	public String getTotalSubdivisionTestCases() {
		return TotalSubdivisionTestCases;
	}
	public void setTotalSubdivisionTestCases(String totalSubdivisionTestCases) {
		TotalSubdivisionTestCases = totalSubdivisionTestCases;
	}
	public String getTotalOBAutomationTestCases() {
		return TotalOBAutomationTestCases;
	}
	public void setTotalOBAutomationTestCases(String totalOBAutomationTestCases) {
		TotalOBAutomationTestCases = totalOBAutomationTestCases;
	}
	public String getTotalBOSAutomationTestCases() {
		return TotalBOSAutomationTestCases;
	}
	public void setTotalBOSAutomationTestCases(String totalBOSAutomationTestCases) {
		TotalBOSAutomationTestCases = totalBOSAutomationTestCases;
	}
	public String getTotalSubDivAutomationTestCases() {
		return TotalSubDivAutomationTestCases;
	}
	public void setTotalSubDivAutomationTestCases(
			String totalSubDivAutomationTestCases) {
		TotalSubDivAutomationTestCases = totalSubDivAutomationTestCases;
	}
	public String getOBManual() {
		return OBManual;
	}
	public void setOBManual(String oBManual) {
		OBManual = oBManual;
	}
	public String getBOSManual() {
		return BOSManual;
	}
	public void setBOSManual(String bOSManual) {
		BOSManual = bOSManual;
	}
	public String getSubDivManual() {
		return SubDivManual;
	}
	public void setSubDivManual(String subDivManual) {
		SubDivManual = subDivManual;
	}
	public String getTotalOBSupportsAutomated() {
		return TotalOBSupportsAutomated;
	}
	public void setTotalOBSupportsAutomated(String totalOBSupportsAutomated) {
		TotalOBSupportsAutomated = totalOBSupportsAutomated;
	}
	public String getTotalBOSSupportsAutomated() {
		return TotalBOSSupportsAutomated;
	}
	public void setTotalBOSSupportsAutomated(String totalBOSSupportsAutomated) {
		TotalBOSSupportsAutomated = totalBOSSupportsAutomated;
	}
	public String getTotalSubDivSupportsAutomated() {
		return TotalSubDivSupportsAutomated;
	}
	public void setTotalSubDivSupportsAutomated(String totalSubDivSupportsAutomated) {
		TotalSubDivSupportsAutomated = totalSubDivSupportsAutomated;
	}
	
	
	FileOutputStream fos=new FileOutputStream("....");
	XSSFWorkBook w1=new 
	
	

*/}
