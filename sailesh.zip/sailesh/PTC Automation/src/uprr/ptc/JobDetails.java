package uprr.ptc;

import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Session;
import javax.mail.Store;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerContext;

public class JobDetails implements Job {

Properties properties = null;
private Session session = null;
private Store store = null;
private Folder inbox = null;

@Override
public void execute(final JobExecutionContext ctx)
throws JobExecutionException {

try {
	
System.out.println("Cron job execution started");

SchedulerContext context = ctx.getScheduler().getContext();

Properties cronProps = (Properties) context.get("CRONPROPS");

 
if ("ON".equalsIgnoreCase(cronProps.getProperty("cronjobstatus"))) {
	SendEmail sm = new SendEmail();
	sm.SendMail();
}

System.out.println("Cron job execution completed");
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
}