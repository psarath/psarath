package uprr.ptc;

import java.util.HashMap;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

/**
 * Servlet implementation class GridModel
 */
@WebServlet("/GridServlet")
public class GridModel extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	GridModel(HashMap<String, String> excelData)
	{
		this.id=excelData.get("id");
		this.Date=excelData.get("date");
		this.Day=excelData.get("day");;
		this.Divya=excelData.get("divya");;
		this.Hemasudha=excelData.get("hemasudha");;
		this.Ather=excelData.get("ather");;
		this.Manaswini=excelData.get("manaswini");;
		this.Ravi=excelData.get("ravi");;
		
	}
       
	private String id;
    private String Date;
    private String Day;
    private String Divya;
    private String Hemasudha;
    private String Ather;
    private String Manaswini;
    private String Ravi;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		this.Date = date;
	}
	public String getDivya() {
		return Divya;
	}
	public void setDivya(String divya) {
		Divya = divya;
	}
	public String getHemasudha() {
		return Hemasudha;
	}
	public void setHemasudha(String hemasudha) {
		Hemasudha = hemasudha;
	}
	public String getAther() {
		return Ather;
	}
	public void setAther(String ather) {
		Ather = ather;
	}
	public String getManaswini() {
		return Manaswini;
	}
	public void setManaswini(String manaswini) {
		Manaswini = manaswini;
	}
	public String getRavi() {
		return Ravi;
	}
	public void setRavi(String ravi) {
		Ravi = ravi;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getDay() {
		return Day;
	}
	public void setDay(String day) {
		this.Day = day;
	}
	
    
	
    

}
