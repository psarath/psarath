package uprr.ptc;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;


public class UtilDates {
	
	
    public static List<Date> currentWeekDaysUpToCurrentDate(){
    	
    	Date currentWeekMpnday = currentWeekMonday();
    	List<Date> dateList = getDaysBetweenDates(currentWeekMpnday,new Date());
    	return dateList;
	}

	public static Date currentWeekMonday(){
		
		Calendar c = Calendar.getInstance();
		c.setFirstDayOfWeek(Calendar.MONDAY);
		c.setTime(new Date());
		int today = c.get(Calendar.DAY_OF_WEEK);
		c.add(Calendar.DAY_OF_WEEK, -today+Calendar.MONDAY);
		System.out.println("Date "+c.getTime());
	    return c.getTime();	
	}
	
	
	public static List<Date> getDaysBetweenDates(Date startdate, Date enddate)
	{
	    List<Date> dates = new ArrayList<Date>();
	    Calendar calendar = new GregorianCalendar();
	    calendar.setTime(startdate);

	    while (calendar.getTime().before(enddate))
	    {
	        Date result = calendar.getTime();
	        dates.add(result);
	        calendar.add(Calendar.DATE, 1);
	    }
	    return dates;
	}
	
	public static void main(String args[]){
		
		System.out.println(currentWeekDaysUpToCurrentDate());
		
	}
	

}
