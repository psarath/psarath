package uprr.ptc;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PTCExcelSheet {
	
	public static void main(String[] args) throws IOException {
	 //int rowCount=0;
	 
	 //private String xlName = excelName;
	//private static final String EXCEL_FILE_LOCATION = ;
	  String fileName = "PTCAutomation";                                             
	FileOutputStream fos=new FileOutputStream("Y:\\Sailesh\\PTC.xlsx");
	//workbook.write(fos);
	
	 XSSFWorkbook workbook = new XSSFWorkbook();
     XSSFSheet sheet = workbook.createSheet("PTCAutomation");
     
     XSSFSheet spreadSheet = workbook.createSheet("Messages");
     XSSFRow row;
     XSSFCell cell;
     XSSFCellStyle style = workbook.createCellStyle();
     CellStyle headding = workbook.createCellStyle();
      for(int i=0;i<10;i++){
    	
			    	 if(i==0){ //Header in Excel
			    	 System.out.println("Begin of Header in "+fileName+".xlsx in row 1");
			    	 row = spreadSheet.createRow((short) i);
			    	 cell = row.createCell(0);
			    	 cell.setCellValue("Id");  
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(1);
			    	 cell.setCellValue("Date");  
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(2);
			    	 cell.setCellValue("Day");
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(3);
			    	 cell.setCellValue("Divya");
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(4);
			    	 cell.setCellValue("Hemasudha");
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(5);
			    	 cell.setCellValue("Ather"); 
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(6);
			    	 cell.setCellValue("Manaswini"); 
			    	 style.setFillForegroundColor(HSSFColor.LIME.index);
			    	 style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    	 cell.setCellStyle(style);
			    	 cell = row.createCell(7);
			    	 cell.setCellValue("Ravi"); 
			      	 System.out.println("Ended creation of Header in "+fileName+".xlsx in row 1");
			     
			          workbook.write(fos);
			    	 fos.close();
			     
			 }
      	}
}
}
     
     
	


