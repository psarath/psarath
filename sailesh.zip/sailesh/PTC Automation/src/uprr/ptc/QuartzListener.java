package uprr.ptc;

import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.annotation.WebListener;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;

@WebListener
public class QuartzListener extends QuartzInitializerListener {

@Override
public void contextInitialized(ServletContextEvent sce) {
super.contextInitialized(sce);
ServletContext ctx = sce.getServletContext();
StdSchedulerFactory factory = (StdSchedulerFactory) ctx
.getAttribute(QUARTZ_FACTORY_KEY);
try {
Properties prop = new Properties();
prop.load(sce.getServletContext().getResourceAsStream(
"/WEB-INF/properties/cron.properties"));
System.out.println(">>>>>>>>>>>>>>>"+prop.getProperty("cronexpression"));

Scheduler scheduler = factory.getScheduler();
 
scheduler.getContext().put("CRONPROPS",prop);
JobDetail jobDetail = JobBuilder.newJob(JobDetails.class).build();     
Trigger trigger = TriggerBuilder
.newTrigger()
.withIdentity("simple")
.withSchedule(
CronScheduleBuilder
.cronSchedule(prop.getProperty("cronexpression")))
.startNow().build();// 0 0/1 * 1/1 * ? *
System.out.println("MODIFIED:::");
scheduler.scheduleJob(jobDetail, trigger);
scheduler.start();
} catch (Exception e) {
ctx.log("There was an error scheduling the job.", e);
}
}

}