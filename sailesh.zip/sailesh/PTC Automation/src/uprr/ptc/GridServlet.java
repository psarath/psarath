package uprr.ptc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.gson.Gson;
import com.google.gson.JsonArray;


/**
 * Servlet implementation class LoadServlet
 * @param <JSONArray>
 */
@WebServlet("/loadgriddata")
public class GridServlet<JSONArray> extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GridServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param JSONSerializer 
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		 List<GridModel> gridModels = new ArrayList<>();
		 List<String> excelHeaders = new ArrayList<String>();
		 String pattern = "yyyy-MM-dd";
     	 SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		 try {
           FileInputStream excelFile = new FileInputStream(new File("C://Users//xsat015//Desktop//PTC.xlsx"));
	       Workbook workbook = new XSSFWorkbook(excelFile);
	       Sheet datatypeSheet = workbook.getSheetAt(0);
	       Iterator<Row> iterator = datatypeSheet.iterator();
             while (iterator.hasNext()) {
         	   HashMap<String, String> ExcelData = new HashMap<String, String>();	 
               Row currentRow = iterator.next();
               Iterator<Cell> cellIterator = currentRow.iterator();
                while (cellIterator.hasNext()) {
               	 Cell currentCell = cellIterator.next();
                 if (currentRow.getRowNum() == 0) {
                	 excelHeaders.add(currentCell.getStringCellValue()); 
                 } else {
                        if (currentCell.getCellType() == Cell.CELL_TYPE_STRING) {
                        	ExcelData.put(excelHeaders.get(currentCell.getColumnIndex()).toLowerCase(),currentCell.getStringCellValue());
                        } else if (currentCell.getCellType() == Cell.CELL_TYPE_NUMERIC && currentCell.getColumnIndex() != 1) {
                        	ExcelData.put(excelHeaders.get(currentCell.getColumnIndex()).toLowerCase(),String.valueOf(currentCell.getNumericCellValue()));
                        } else if (currentCell.getColumnIndex() == 1 && currentCell.getDateCellValue() != null) {
                        	String date = simpleDateFormat.format(currentCell.getDateCellValue());
                        	ExcelData.put(excelHeaders.get(currentCell.getColumnIndex()).toLowerCase(),date);
                        }
                    }	  
                  }
                if (!ExcelData.isEmpty())  {
                  GridModel gridModel = new GridModel(ExcelData);
                  gridModels.add(gridModel);
                }
                
             }
             workbook.close();
             excelFile.close();
	       } catch (FileNotFoundException e) {
	          e.printStackTrace();
	       } catch (IOException e) {
	          e.printStackTrace();
	       }

		PrintWriter out = response.getWriter();
		
		out.print(getJsonString(gridModels));
	}
	
	public String getJsonString(List<GridModel> rows){
	  Gson gson = new Gson();
	  JsonArray jsonArray = gson.toJsonTree(rows).getAsJsonArray();
	  return gson.toJson(jsonArray);
    }

}
