$(function() {
		//"use strict";
      jQuery("#grid1").jqGrid(
		        {
				  colNames : ['sno','Date', 'Day', 'Divya', 'Hemasudha',
						'Ather', 'Manaswini', 'Ravi' ],
				  colModel : [

							 {
								name : 'id',
								index : 'id',
								width : 50,
								hidden:true,
								search : false
							 }, {
								name : 'Date',
								index : 'Date',
								width : 100,
								searchoptions:{dataInit:datePick, attr:{title:'Select Date'}, formatter: 'date'}
							}, {
								name : 'Day',
								index : 'Day',
								width : 100,
								search : false
							}, {
								name : 'Divya',
								index : 'Divya',
								width : 100,
								search : false
							}, {
								name : 'Hemasudha',
								index : 'Hemasudha',
								width : 100,
								search : false
							}, {
								name : 'Ather',
								index : 'Ather',
								width : 100,
								search : false
							}, {
								name : 'Manaswini',
								index : 'Manaswini',
								width : 100,
								search : false
							}, {
								name : 'Ravi',
								index : 'Ravi',
								width : 100,
								search : false
							}

					      ],
						  gridview: true,
						  loadonce: true,
						  ondblClickRow : function(rowId) {
						    var rowData = jQuery(this).getRowData(rowId);
							$('#id').val(rowData['id']);
							$('#Date').attr('value', rowData['Date']);
							$('#Day').val(rowData['Day']);
							$('#Divya').val(rowData['Divya']);
							$('#Hemasudha').val(rowData['Hemasudha']);
							$('#Ather').val(rowData['Ather']);
							$('#Manaswini').val(rowData['Manaswini']);
							$('#Ravi').val(rowData['Ravi']);
						  },
						  jsonReader : {
							root: function (obj) { return obj; },
							page: function (obj) { return jQuery("#grid1").jqGrid('getGridParam', 'pager'); },
							total: function (obj) { return Math.ceil(obj.length / jQuery("#grid1").jqGrid('getGridParam', 'rowNum')); },
							records: function (obj) { return obj.length; },
   							cell : "cell",
							id : "id",
						  },
						   onSelectRow : function(ids) {
						   
						   },
						   datatype : 'json',
						   mtype : 'GET',
						   url : "loadgriddata",
						   rowNum : 5,
						   rownumbers : true,
						   autowidth: true,
						   height : 250, 
						   rowList : [ 5, 10, 15 ],
						   viewrecords : true,
						   pager : '#pager',
						   caption : "UPRR PTC Automation DashBoard details are given below"
						}).navGrid('#pager',{edit:false,add:false,del:false});
		
              jQuery("#grid1").jqGrid('navGrid','hideCol',"id");
              jQuery("#grid1").jqGrid('filterToolbar',{searchOperators : true});
	});

     datePick = function(elem) {
   	   jQuery(elem).datepicker({
		changeYear: true,
        changeMonth: true,
        showButtonPanel: true,
        selectWeek:true,
        dateFormat: 'yy-mm-dd',
        onSelect: function (date) {
    	var d = new Date(date);
        var d1 = new Date(date);
        var index = d.getDay();
        if(index == 0) {
          d.setDate(d.getDate() - 6);   
          d1.setDate(d1.getDate() - 2);   
        } else if(index == 1) {
          d.setDate(d.getDate());
          d1.setDate(d1.getDate()+4);               
        } else if(index != 1 && index > 0) {
          d.setDate(d.getDate() - (index - 1));
          d1.setDate(d1.getDate() + (index + 1));
        }
         d = formatDate(d);
         d1 = formatDate(d1);
         
        /* if (this.id.substr(0, 3) === "gs_") {
          // call triggerToolbar only in case of searching toolbar
            setTimeout(function () {
                $("#grid1")[0].triggerToolbar();
            }, 100);
         }*/
            var myfilter = { groupOp: "AND", rules: []};

            // addFilteritem("invdate", "lt", "2007-10-04");
            myfilter.rules.push({ field: "Date", op: "ge", data: d});
            
            // addFilteritem("invdate", "gt", "2007-09-06");
            myfilter.rules.push({field: "Date", op: "le", data: d1});

            jQuery("#grid1")[0].p.search = myfilter.rules.length>0;
            $.extend(jQuery("#grid1")[0].p.postData,{filters:JSON.stringify(myfilter)});
            jQuery("#grid1").trigger("reloadGrid",[{page:1}]);
            $(this).datepicker("setDate", date);
           }
     });
};

   /*Convert to client date format.*/
  function formatDate(d) {
    var date = d,
    month = '' + (date.getMonth() + 1),
    day = '' + date.getDate(),
    year = date.getFullYear();
    
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  /*Dialog information message  */
  function informationMessage(msg) {
    jQuery("#successDialog").text(msg);
    jQuery("#successDialog").dialog({
	  open: function(event, ui) {
	    jQuery(".ui-dialog-titlebar-close", ui.dialog | ui).hide();
	  },
	  buttons: {
	    "OK": function() {
	        $(this).dialog("close");
	    }
	  }
    });
  }

  /*Resets all form fields.*/
  function resetIt() {
	$('#id').val('');
	$('#Date').attr('value', '');
	$('#Day').val('');
	$('#Divya').val('');
	$('#Hemasudha').val('');
	$('#Ather').val('');
	$('#Manaswini').val('');
	$('#Ravi').val('');

  }

  /*Saves new or updated record into excel sheet and updated data table.*/
  function saveIt() {
	$.ajax({
		url : 'PTCExcelSheetServlet',
		data : {
		  'Id' : $('#id').val(),
		  'Date' : $('#Date').val(),
		  'Day' : $('#Day').val(),
		  'Divya' : $('#Divya').val(),
		  'Hemasudha' : $('#Hemasudha').val(),
		  'Ather' : $('#Ather').val(),
		  'Manaswini' : $('#Manaswini').val(),
		  'Ravi' : $('#Ravi').val()
		},
		error : function() {
		  informationMessage("Failed to save record");
		},
		/* dataType : 'jsonp', */ 
		success : function(data) {
		  resetIt();
		  jQuery("#grid1").jqGrid('setGridParam',{datatype:'json'}).trigger('reloadGrid');
		  informationMessage("Recored saved successfully");
		},
		type : 'GET'
	});
  }
