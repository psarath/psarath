package com.payroll.pdf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfJava {

	 public static final String DEST = "C:/pdf/nested_tables2.pdf";
	    public static void main(String[] args) throws IOException, DocumentException {
	        File file = new File(DEST);
	        file.getParentFile().mkdirs();
	        new PdfJava().createPdf(DEST);
	    }
	 
	    public void createPdf(String dest) throws IOException, DocumentException {
	        Document document = new Document();
	        PdfWriter.getInstance(document, new FileOutputStream(dest));
	        document.open();
	
	        
	        PdfPTable table = new PdfPTable(5);
	        table.setSplitLate(false);
	        table.setWidths(new int[]{90,40,40,90,40});
	        table.setWidthPercentage(100);
	        
	        Font boldFont = new Font(Font.FontFamily.TIMES_ROMAN, 13, Font.BOLD);
	        
	        PdfPCell pcell0 = new PdfPCell(new Phrase("Attendance Details",boldFont));  
	        pcell0.setColspan(2);
			table.addCell(pcell0);
			
			
	        /*table.addCell("value");*/
	        
	        PdfPCell pcell0111 = new PdfPCell(new Phrase("value",boldFont));  
	        pcell0111.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0111);
	        
	        
	        PdfPCell pcell1 = new PdfPCell();    
	        pcell1.setColspan(2);
	        pcell1.setBorder(Rectangle.NO_BORDER);
			table.addCell(pcell1);
	         
	        
	        PdfPCell pcell01 = new PdfPCell(new Phrase("Present")); 
	        pcell01.setMinimumHeight(30);
	        pcell01.setColspan(2);
			table.addCell(pcell01);
	        
	        PdfPCell pcell0112 = new PdfPCell(new Phrase("10 days"));  
	        pcell0112.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0112);
	        
	        PdfPCell pcell2 = new PdfPCell();  
	        pcell2.setBorder(Rectangle.NO_BORDER);
	        pcell2.setColspan(3);
			table.addCell(pcell2);
		    
			PdfPCell pcell20 = new PdfPCell(new Phrase("Earnings",boldFont)); 
			pcell20.setMinimumHeight(0);
			table.addCell(pcell20);
			
			PdfPCell pcell0113 = new PdfPCell(new Phrase("Amount",boldFont));  
			pcell0113.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0113);
			
			PdfPCell pcell0114 = new PdfPCell(new Phrase("Gross Salary",boldFont));  
			pcell0114.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0114);
			
			PdfPCell pcell0115 = new PdfPCell(new Phrase("Deductions",boldFont));  
			table.addCell(pcell0115);
	        
			PdfPCell pcell0116 = new PdfPCell(new Phrase("Amount",boldFont));  
			pcell0116.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0116);
	        
	        
	        
	        PdfPCell pcell012 = new PdfPCell(new Phrase("Basic Salary")); 
	        pcell012.setBorderWidthBottom(0);
			table.addCell(pcell012);
			
			PdfPCell pcell013 = new PdfPCell(new Phrase("2300.00"));
			pcell013.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell013.setBorderWidthBottom(0);
			table.addCell(pcell013);
			
			PdfPCell pcell014 = new PdfPCell(new Phrase("2400.00"));
			pcell014.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell014.setBorderWidthBottom(0);
			table.addCell(pcell014);
			
			PdfPCell pcell015 = new PdfPCell(new Phrase("ESI"));
			pcell015.setBorderWidthBottom(0);
			table.addCell(pcell015);
			
			PdfPCell pcell016 = new PdfPCell(new Phrase("120.00"));
			pcell016.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell016.setBorderWidthBottom(0);
			table.addCell(pcell016);
			
	        
	        
	        PdfPCell pcell023 = new PdfPCell(new Phrase("HRA"));  
	        pcell023.setBorderWidthBottom(0);
	        pcell023.setBorderWidthTop(0);
			table.addCell(pcell023);
			
			PdfPCell pcell024 = new PdfPCell(new Phrase("2300.00"));
			pcell024.setHorizontalAlignment(Element.ALIGN_CENTER);
	        pcell024.setBorderWidthBottom(0);
	        pcell024.setBorderWidthTop(0);
			table.addCell(pcell024);
			
			PdfPCell pcell025 = new PdfPCell(new Phrase("2400.00"));
			pcell025.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell025.setBorderWidthBottom(0);
			pcell025.setBorderWidthTop(0);
			table.addCell(pcell025);
			
			PdfPCell pcell017 = new PdfPCell(new Phrase("P F")); 
			pcell017.setBorderWidthBottom(0);
			pcell017.setBorderWidthTop(0);
			table.addCell(pcell017);
			
			PdfPCell pcell018 = new PdfPCell(new Phrase("328.00")); 
			pcell018.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell018.setBorderWidthBottom(0);
			pcell018.setBorderWidthTop(0);
			table.addCell(pcell018);
			
			
		    PdfPCell pcell026 = new PdfPCell(new Phrase("Conveyance Allowance"));  
		    pcell026.setBorderWidthBottom(0);
		    pcell026.setBorderWidthTop(0);
		    table.addCell(pcell026);
				
		    PdfPCell pcell027 = new PdfPCell(new Phrase("2300.00"));
		    pcell027.setHorizontalAlignment(Element.ALIGN_CENTER);
		    pcell027.setBorderWidthBottom(0);
		    pcell027.setBorderWidthTop(0);
		    table.addCell(pcell027);
				
		    PdfPCell pcell028 = new PdfPCell(new Phrase("2400.00"));
		    pcell028.setHorizontalAlignment(Element.ALIGN_CENTER);
		    pcell028.setBorderWidthBottom(0);
		    pcell028.setBorderWidthTop(0);
		    table.addCell(pcell028);
		    
		    PdfPCell pcell019 = new PdfPCell(new Phrase(""));
		    pcell019.setBorderWidthBottom(0);
		    pcell019.setBorderWidthTop(0);
			table.addCell(pcell019);
			
			PdfPCell pcell020 = new PdfPCell(new Phrase(""));
			pcell020.setBorderWidthBottom(0);
			pcell020.setBorderWidthTop(0);
			table.addCell(pcell020);
		    

	        PdfPCell pcell029 = new PdfPCell(new Phrase("Other Allowances"));  
	        pcell029.setBorderWidthBottom(0);
	        pcell029.setBorderWidthTop(0);
			table.addCell(pcell029);
			
			PdfPCell pcell030 = new PdfPCell(new Phrase("2300.00")); 
			pcell030.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell030.setBorderWidthBottom(0);
			pcell030.setBorderWidthTop(0);
			table.addCell(pcell030);
			
			PdfPCell pcell031 = new PdfPCell(new Phrase("2400.00"));  
			pcell031.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell031.setBorderWidthBottom(0);
			pcell031.setBorderWidthTop(0);
			table.addCell(pcell031);
			
			PdfPCell pcell0191 = new PdfPCell(new Phrase(""));
			pcell0191.setBorderWidthBottom(0);
			pcell0191.setBorderWidthTop(0);
			table.addCell(pcell0191);
				
		    PdfPCell pcell0192 = new PdfPCell(new Phrase(""));
		    pcell0192.setBorderWidthBottom(0);
		    pcell0192.setBorderWidthTop(0);
		    table.addCell(pcell0192);
		    
		    PdfPCell pcell0117 = new PdfPCell(new Phrase("Total Earnings",boldFont));  
			table.addCell(pcell0117);
	        
			PdfPCell pcell0118 = new PdfPCell(new Phrase("1200"));  
			pcell0118.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0118);
			
			PdfPCell pcell0119 = new PdfPCell(new Phrase("122"));  
			pcell0119.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0119);
	       
			PdfPCell pcell0120 = new PdfPCell(new Phrase("Total Deductions",boldFont));  
			table.addCell(pcell0120);
	        
			PdfPCell pcell0121 = new PdfPCell(new Phrase("448.00"));  
			pcell0121.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0121);
	        
	       
			
			table.addCell("");
	        table.addCell("");
	        table.addCell("");
	        
	        PdfPCell pcell9 = new PdfPCell(new Phrase("Net Amount",boldFont));
	        pcell9.setMinimumHeight(25);
		    table.addCell(pcell9);
		    
		    PdfPCell pcell10 = new PdfPCell(new Phrase("6,300"));
		    pcell10.setHorizontalAlignment(Element.ALIGN_CENTER);
		    table.addCell(pcell10);
		    
		    
	        /*PdfPCell pcell9 = new PdfPCell();  
	        pcell9.setMinimumHeight(20);
	        pcell9.setBorder(Rectangle.NO_BORDER);
	        pcell9.setColspan(2);
			table.addCell(pcell9);*/
	        
		    PdfPCell pcell0122 = new PdfPCell(new Phrase("Employee contribution",boldFont));  
			table.addCell(pcell0122);
		    
			PdfPCell pcell0123 = new PdfPCell(new Phrase("Amount",boldFont));  
			pcell0123.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0123);
			
			PdfPCell pcell0124 = new PdfPCell(new Phrase("Gross Salary",boldFont));  
			pcell0124.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0124);
			
	      
	        
	        PdfPCell pcell4 = new PdfPCell();  
	        pcell4.setBorder(Rectangle.NO_BORDER);
	        pcell4.setColspan(2);
			table.addCell(pcell4);
			
			
			
			PdfPCell pcell30 = new PdfPCell(new Phrase("Employer�s PF"));  
			pcell30.setBorderWidthBottom(0);
			table.addCell(pcell30);
			
			PdfPCell pcell33 = new PdfPCell(new Phrase("1200"));
			pcell33.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell33.setBorderWidthBottom(0);
			pcell33.setBorderWidthTop(0);
	        table.addCell(pcell33);
	        
	        PdfPCell pcell34 = new PdfPCell(new Phrase("200"));
	        pcell34.setHorizontalAlignment(Element.ALIGN_CENTER);
	        pcell34.setBorderWidthBottom(0);
	        pcell34.setBorderWidthTop(0);
	        table.addCell(pcell34);
		
	        
	        PdfPCell pcell5 = new PdfPCell();  
	        pcell5.setBorder(Rectangle.NO_BORDER);
	        pcell5.setColspan(2);
			table.addCell(pcell5);
			
			PdfPCell pcell31 = new PdfPCell(new Phrase("EMP ESI"));  
			pcell31.setBorderWidthBottom(0);
			pcell31.setBorderWidthTop(0);
			table.addCell(pcell31);
			
			PdfPCell pcell32 = new PdfPCell(new Phrase("1200"));
			pcell32.setHorizontalAlignment(Element.ALIGN_CENTER);
			pcell32.setBorderWidthBottom(0);
			pcell32.setBorderWidthTop(0);
	        table.addCell(pcell32);
	        
	        PdfPCell pcell35 = new PdfPCell(new Phrase("200")); 
	        pcell35.setHorizontalAlignment(Element.ALIGN_CENTER);
	        pcell35.setBorderWidthBottom(0);
	        pcell35.setBorderWidthTop(0);
	        table.addCell(pcell35);
	        
	        
	        PdfPCell pcell6 = new PdfPCell();  
	        pcell6.setBorder(Rectangle.NO_BORDER);
	        pcell6.setColspan(2);
			table.addCell(pcell5);
			
			PdfPCell pcell0125 = new PdfPCell(new Phrase("Total",boldFont));  
			table.addCell(pcell0125);
			
			PdfPCell pcell0126 = new PdfPCell(new Phrase("1200"));  
			pcell0126.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0126);
			
			PdfPCell pcell0127 = new PdfPCell(new Phrase("122"));  
			pcell0127.setHorizontalAlignment(Element.ALIGN_CENTER);
			table.addCell(pcell0127);
	        
	        
	        PdfPCell pcell7 = new PdfPCell();  
	        pcell7.setBorder(Rectangle.NO_BORDER);
	        pcell7.setColspan(2);
			table.addCell(pcell5);
		      
	      
			
			/* Image background = Image.getInstance("/root/Desktop/narasimha.jpg");
		     float width = document.getPageSize().getWidth();
		     float height = document.getPageSize().getHeight();
		     PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(dest));*/
		     //writer.getDirectContentUnder().addImage(background, width, 0, 0, height, 0, 0);
		                
				    
		    /*    
		     	PdfReader Read_PDF_To_Watermark = new PdfReader("/home/pdf/one.pdf");
		     	
	            int number_of_pages = Read_PDF_To_Watermark.getNumberOfPages();
	            PdfStamper stamp = new PdfStamper(Read_PDF_To_Watermark, new FileOutputStream("New_PDF_With_Watermark_Image.pdf"));
	            int i = 0;
	            Image watermark_image = Image.getInstance("/root/Desktop/narasimha.jpg");
	            watermark_image.setAbsolutePosition(200, 400);
	            PdfContentByte add_watermark;            
	            while (i < number_of_pages) {
	              i++;
	              add_watermark = stamp.getUnderContent(i);
	              add_watermark.addImage(watermark_image);
	            }
	            stamp.close();*/
	            
	            document.add(table);
		        document.close();
	            
	      
	    }

}

