package com.payroll.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;

import com.payroll.dao.SalaryDao;
import com.payroll.entity.Salary;
import com.payroll.service.SalaryService;

public class SalaryServiceimpl implements SalaryService {
	
	@Autowired
	private SalaryDao salaryDao;

	@Override
	public void storeSalary(Salary salary) {		
		// TODO Auto-generated method stub
		salaryDao.storeSalary(salary);
		
	}

}
