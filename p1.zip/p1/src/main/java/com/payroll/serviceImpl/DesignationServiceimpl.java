package com.payroll.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payroll.dao.DesignationDao;
import com.payroll.entity.Designations;
import com.payroll.service.DesignationService;

@Service
public class DesignationServiceimpl implements DesignationService {
	
	@Autowired
	private DesignationDao  designationDao; 

	@Override
	public List<Designations> getAlldesignations() {
		
		List<Designations> designationsList = designationDao.getAllDesignations(); 
		// TODO Auto-generated method stub
		return designationsList;
	}
	
	

}
