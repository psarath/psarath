package com.payroll.dao;

import com.payroll.entity.ProvidentFund;

public interface ProvidentFundDao {
	
	public void storeProvidentFund(ProvidentFund providentFund);

}
