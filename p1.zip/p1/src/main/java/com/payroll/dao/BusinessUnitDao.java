package com.payroll.dao;

import java.util.List;

import com.payroll.entity.BusinessUnit;

public interface BusinessUnitDao {
	
	List<BusinessUnit> getAllbusinessUnit();
	
	

}
