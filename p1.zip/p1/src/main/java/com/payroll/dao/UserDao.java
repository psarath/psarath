package com.payroll.dao;

public interface UserDao {

}
