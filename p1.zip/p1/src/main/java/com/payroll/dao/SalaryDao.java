package com.payroll.dao;

import com.payroll.entity.Salary;

public interface SalaryDao {


	public void storeSalary(Salary salary);

	

}
