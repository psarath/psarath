package com.payroll.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payroll.dao.ProvidentFundDao;
import com.payroll.entity.ProvidentFund;

@Repository
public class ProvidentFundDaoimpl implements ProvidentFundDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void storeProvidentFund(ProvidentFund providentFund) {
		Session s = sessionFactory.getCurrentSession();
		Transaction trans = s.beginTransaction();
		s.save(providentFund);
		trans.commit();
		
	}

}
