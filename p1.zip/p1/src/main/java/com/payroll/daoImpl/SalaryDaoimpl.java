package com.payroll.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payroll.dao.SalaryDao;
import com.payroll.entity.Salary;

@Repository
public class SalaryDaoimpl implements SalaryDao {
	
    @Autowired
	private SessionFactory sessionFactory;

	@Override
	public void storeSalary(Salary salary) {
		
		Session s = sessionFactory.getCurrentSession();
		Transaction trans = s.beginTransaction();
		s.save(salary);
		trans.commit();
		// TODO Auto-generated method stub
		
	}

}
