package com.payroll.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payroll.dao.EmployeeDao;
import com.payroll.entity.Employee;

@Repository
public class EmployeeDaoimpl implements EmployeeDao {
	
	@Autowired 
	private SessionFactory sessionFactory;
	
	@Override
	public void storeEmployee(Employee employee) {
		 
		   Session s =  sessionFactory.getCurrentSession();
		   Transaction trans=s.beginTransaction();
		   s.save(employee);
		   trans.commit();
	}
	
	@Override
	public List<Employee> getAllEmployeeList() {
		
		  Session s =  sessionFactory.getCurrentSession();
		   Transaction trans1 = s.beginTransaction();
		   List<Employee> employeeList  = (List<Employee>) s.createQuery("from Employee employee").list();
		   return employeeList;
	}

	@Override
	public List<Employee> getAllEmployeeListWithOffset(String offset) {
		  Integer maxResult = 15;
		  Session s =  sessionFactory.getCurrentSession();
		   Transaction trans1 = s.beginTransaction();
		   List<Employee> employeeList  = (List<Employee>) s.createQuery("from Employee employee").setFirstResult(Integer.parseInt(offset)).setMaxResults(maxResult).list();
		   return employeeList;
		
	}

	@Override
	public Employee getEmployeeByEmployeeId(Long employeeId) {
			// TODO Auto-generated method stub
				Session session = sessionFactory.getCurrentSession();
				Transaction trans = session.beginTransaction();
				List<Employee> Employees = new ArrayList<Employee>();
				Employees = session.createQuery("from Employee emp where emp.employeeID =:employeeId" ).setCacheable(true).setLong( "employeeId", employeeId).list();
				trans.commit();
				if (Employees.size() > 0) {
					return Employees.get(0);
				} else {
					return null;
				}
				
	    }

	@Override
	public List<Employee> getemployeeListByBusinessUnitID(Long businessUnitID) {
		// TODO Auto-generated method stub
		   Session session = sessionFactory.getCurrentSession();
		   Transaction trans = session.beginTransaction();
		   List<Employee> employeeList  = (List<Employee>)session.createQuery("from Employee emp where emp.businessUnit.businessUnitID =:businessUnitID").setLong("businessUnitID", businessUnitID).list();
		   trans.commit();
		   return employeeList;
			
	}


	 
	

}
