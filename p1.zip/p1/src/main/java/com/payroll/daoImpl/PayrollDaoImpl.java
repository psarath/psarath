package com.payroll.daoImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.payroll.dao.PayrollDao;
import com.payroll.entity.Payroll;

@Repository
public class PayrollDaoImpl implements PayrollDao  {
	
	@Autowired
	private SessionFactory sessionFactory;

	public List<Payroll> getAllPayroll() {
		Session session = sessionFactory.getCurrentSession();
		Transaction trans1 = session.beginTransaction();
		List<Payroll> payroll = session.createQuery("from Payroll payroll").list();
		trans1.commit();
		return payroll;
	}
	
	

}
