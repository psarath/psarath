package com.payroll.controller;


import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.BusinessUnit;
import com.payroll.entity.Designations;
import com.payroll.entity.Employee;
import com.payroll.entity.ProvidentFund;
import com.payroll.entity.Salary;
import com.payroll.service.BusinessUnitService;
import com.payroll.service.DesignationService;
import com.payroll.service.EmployeeService;
import com.payroll.service.ProvidentFundService;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;
import com.thoughtworks.xstream.io.json.JsonWriter;


@Controller  
public class EmployeeController {  
	
	
	@Autowired 
	private SessionFactory sessionFactory;  
	
	@Autowired
	private BusinessUnitService businessUnitService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private DesignationService designationService;
	
	@Autowired
	private ProvidentFundService providentFundService;

	
    @RequestMapping("/employeeList")  
    public ModelAndView Registration(@ModelAttribute BusinessUnit businessUnit) {  
    		
    	   ModelAndView m = new ModelAndView();
    	   
    	   List<BusinessUnit>  businessUnitList = businessUnitService.getAllbusinessUnit();
	  	   m.addObject("businessUnitList",businessUnitList);
	  	   
	  	   List<Designations> designationsList = designationService.getAlldesignations();
	       m.addObject("designationsList",designationsList);
	  	   
	       
	  	   m.setViewName("employeeList");
	       return m; 
	       
	     /* @RequestMapping(value = "/getemployeeList", method = RequestMethod.POST)
	      public @ResponseBody String employeeList() {
	    	String resultJson = null;
	      List<Employee> employeeList1 = employeeService.getAllEmployeeList();
	      
	      r esultJson = toJSON(employeeList1);
	      return resultJson;
	      }*/
	      
	            
	       
    }  
    
@Transactional
@RequestMapping(value = "/storeEmployee" , method = RequestMethod.POST)     
public ModelAndView store(@RequestParam(value = "json", required = false) String json,MultipartHttpServletRequest request) throws JSONException, ParseException, IOException {  
     	
	
		String jsonc = "{" + json + "}";
		JSONObject jsonObj = new JSONObject(jsonc);
		Employee employee = new Employee();
		
		MultipartFile multiFile = null;
		Iterator<String> itrator = request.getFileNames();
		if(itrator.hasNext()){
	        multiFile = request.getFile(itrator.next());
		}
		if(multiFile != null && multiFile.getOriginalFilename() != null && !multiFile.getOriginalFilename().isEmpty()){
			 employee.setDoc_File(multiFile.getBytes());
			 employee.setFile_Name(multiFile.getOriginalFilename());
			 employee.setFile_Content_Type(multiFile.getContentType());
		 }
		
		if (jsonObj.has("firstName") && !(jsonObj.getString("firstName").isEmpty())){
			employee.setFirstName(jsonObj.getString("firstName"));
		}
		
		if (jsonObj.has("lastName") && !(jsonObj.getString("lastName").isEmpty())){
			employee.setLastName(jsonObj.getString("lastName"));
		}
		
		if (jsonObj.has("employeeUnique Id") && !(jsonObj.getString("employeeUnique Id").isEmpty())){
			employee.setEmployeeUniqueId(jsonObj.getString("employeeUnique Id"));
		}
		
		if (jsonObj.has("address") && !(jsonObj.getString("address").isEmpty())){
			employee.setAddress(jsonObj.getString("address"));
			}
		
		if (jsonObj.has("phone") && !(jsonObj.getString("phone").isEmpty())){
			employee.setPhone(jsonObj.getString("phone"));
			}
		
		 DateFormat df = new SimpleDateFormat("mm/dd/yyyy");
		
		
		if (jsonObj.has("joiningDate") && !(jsonObj.getString("joiningDate").isEmpty())){
			employee.setJoiningDate(df.parse(jsonObj.getString("joiningDate")));
			}
		
		
		if (jsonObj.has("leavingDate") && !(jsonObj.getString("leavingDate").isEmpty())){
			employee.setLeavingDate(df.parse(jsonObj.getString("leavingDate")));
			}
		
		if (jsonObj.has("emailId") && !(jsonObj.getString("emailId").isEmpty())){
			employee.setEmailId(jsonObj.getString("emailId"));
			}
		
		if (jsonObj.has("bankDetails") && !(jsonObj.getString("bankDetails").isEmpty())){
			employee.setBankDetails(jsonObj.getString("bankDetails"));
			}
		
		if (jsonObj.has("location") && !(jsonObj.getString("location").isEmpty())){
			employee.setLocation(jsonObj.getString("location"));
			}
		
		if (jsonObj.has("businessUnit") && !(jsonObj.getString("businessUnit").isEmpty())){
			BusinessUnit businessUnit = new BusinessUnit();
			businessUnit.setBusinessUnitID(Long.valueOf(jsonObj.getString("businessUnit")));
			employee.setBusinessUnit(businessUnit);
			}
		
		if (jsonObj.has("designation") && !(jsonObj.getString("designation").isEmpty())){
			Designations designations = new Designations();
			designations.setDesignationID(Long.valueOf(jsonObj.getString("designation")));
			employee.setDesignation(designations);
			}
		
		   Session s =  sessionFactory.getCurrentSession();
		   Transaction trans=s.beginTransaction();
		   s.save(employee);
		   trans.commit();
		   
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("employee");
	       return m; 
		
		
    }  

@RequestMapping(value = "/settingStoreSalary" , method = RequestMethod.POST) 
public ModelAndView settingStoreSalary(@RequestParam(value = "json", required = false) String json,MultipartHttpServletRequest request) throws JSONException, ParseException, IOException {  
 	
		   String jsonc = "{" + json + "}";
		   JSONObject jsonObj = new JSONObject(jsonc);
		   Salary salary = new Salary();
		   ProvidentFund providetFund = new ProvidentFund();
			
		   MultipartFile multiFile = null;
		   Iterator<String> itrator = request.getFileNames();
		   if(itrator.hasNext()){
		      multiFile = request.getFile(itrator.next());
			}
		   if(multiFile != null && multiFile.getOriginalFilename() != null && !multiFile.getOriginalFilename().isEmpty()){
				
			 }
	
		  if (jsonObj.has("hra") && !(jsonObj.getString("hra").isEmpty())){
			 salary.setHra(jsonObj.getString("hra"));
			 }
		  
		  if (jsonObj.has("esi") && !(jsonObj.getString("esi").isEmpty())){
			  salary.setEsi(jsonObj.getString("esi"));
				 }
		  
		  if (jsonObj.has("esino") && !(jsonObj.getString("esino").isEmpty())){
			  salary.setEsino(jsonObj.getString("esino"));
				 }
		  
		  if (jsonObj.has("conveyanceAllowance") && !(jsonObj.getString("conveyanceAllowance").isEmpty())){
			  salary.setConveyanceAllowance(jsonObj.getString("conveyanceAllowance"));
				 }
		  
		  if (jsonObj.has("medicalAllowance") && !(jsonObj.getString("medicalAllowance").isEmpty())){
			  salary.setMedicalAllowance(jsonObj.getString("medicalAllowance"));
				 }
		  
		  if (jsonObj.has("otherAllowances") && !(jsonObj.getString("otherAllowances").isEmpty())){
			  salary.setOtherAllowances(jsonObj.getString("otherAllowances"));
				 }
		  
		  if (jsonObj.has("basic") && !(jsonObj.getString("basic").isEmpty())){
			  salary.setBasic(jsonObj.getString("basic"));
				 }
		  
		  if (jsonObj.has("tax") && !(jsonObj.getString("tax").isEmpty())){
			  salary.setTax(jsonObj.getString("tax"));
				 }
		  
		  if (jsonObj.has("grossSalary") && !(jsonObj.getString("grossSalary").isEmpty())){
			  salary.setGrossSalary(jsonObj.getString("grossSalary"));
				 }
		  
		  if (jsonObj.has("netSalary") && !(jsonObj.getString("netSalary").isEmpty())){
			  salary.setNetSalary(jsonObj.getString("netSalary"));
				 }
		  
		  
		
	     Session s =  sessionFactory.getCurrentSession();
	     Transaction trans=s.beginTransaction();
	     s.save(salary); 
	     
	     if (jsonObj.has("pfAccount") && !(jsonObj.getString("pfAccount").isEmpty())){
			  providetFund.setPfAccount(jsonObj.getString("pfAccount"));
				 } 
		 
	
	     Session s1 = sessionFactory.getCurrentSession();
	     Transaction trans1 = s1.beginTransaction();
	     s1.save(providetFund);
	     
	     trans.commit();
	   
	     ModelAndView m = new ModelAndView();
	     m.setViewName("salary");
	     return m;
	     
	     
	
}

		
		@RequestMapping(value = "/getemployeeList", method = RequestMethod.POST)
		public @ResponseBody String employeeList(@RequestParam(value = "offset", required = false) String offSet) {  
			   String resultJson = null;
			   List<Employee>  employeeList = employeeService.getAllEmployeeListWithOffset(offSet);
			   
			   resultJson =  toJSON(employeeList);
			   return resultJson;
		}
		public String toJSON(Object obj){
		    XStream xstream = new XStream(new JsonHierarchicalStreamDriver() {
		        public HierarchicalStreamWriter createWriter(Writer writer) {
		            return new JsonWriter(writer, JsonWriter.DROP_ROOT_MODE);
		        }
		    });
		    return xstream.toXML(obj);
   }
		
		@RequestMapping(value = "/displayEmployeeImage/{employeeId}" , method = RequestMethod.GET)
	     public void displayEmployeeImage(@PathVariable Long employeeId,HttpServletRequest request,HttpServletResponse response,HttpSession session) {
	    	 
		 Employee emp = employeeService.getEmployeeByEmployeeId(employeeId);
		 try {
			 
			if(emp != null && emp.getDoc_File() != null)
			{
				emp.setFile_Content_Type("image/jpeg");
				InputStream in = new ByteArrayInputStream(emp.getDoc_File());
				BufferedImage bi = ImageIO.read(in);
				OutputStream out = response.getOutputStream();
				ImageIO.write(bi, "jpg", out);
				out.close();
			}
			
		 } catch (IOException e) {
			e.printStackTrace();
		 } 
		 catch (Exception e1) {
			e1.printStackTrace();
		 }
		
	  }
		
		
		@RequestMapping(value = "/employeeView" , method = RequestMethod.GET)
		public ModelAndView Registration(@RequestParam(value = "employeeId", required = false) Long employeeId) {  
    		
			Employee emp = employeeService.getEmployeeByEmployeeId(employeeId);
			 
			
	    	   ModelAndView m = new ModelAndView();
	    	   
	    	   List<BusinessUnit>  businessUnitList = businessUnitService.getAllbusinessUnit();
		  	   m.addObject("businessUnitList",businessUnitList);
		  	   
		  	   List<Designations> designationsList = designationService.getAlldesignations();
		       m.addObject("designationsList",designationsList);
	    	   
	    	   m.setViewName("employeeView");
	    	   m.addObject("emp",emp);
		       return m; 
		       
		}
		
		@RequestMapping(value = "/getemployeeView" , method = RequestMethod.POST)
		public @ResponseBody String employeeView(@RequestParam (value = "employeeId" , required = false) Long employeeId) {
			String resultJson = null;
			
			Employee emp = employeeService.getEmployeeByEmployeeId(employeeId);
			
			resultJson =  toJSON(emp);
			return resultJson;
			
		}
	
		
		
} 