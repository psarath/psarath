package com.payroll.controller;

import java.io.Writer;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.Designations;
import com.payroll.service.DesignationService;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;
import com.thoughtworks.xstream.io.json.JsonWriter;

@Controller  
public class DesignationsController {  
	
	
	@Autowired 
	private SessionFactory sessionFactory;
	
	
	@Autowired 
	private DesignationService designationService;
	
    @RequestMapping("/designationsList")  
    public ModelAndView designationsList(@ModelAttribute Designations designations) {  
    	
    	   
    
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("designationsList");
	       return m;
    }  
    
    @RequestMapping(value = "/getdesignationsList", method = RequestMethod.POST)
    public @ResponseBody String designationsList() {  
    	   String resultJson = null;
    	   List<Designations>  designationList = designationService.getAlldesignations();
    	   
    	   resultJson =  toJSON(designationList);
		   return resultJson;
    }
    public String toJSON(Object obj){
        XStream xstream = new XStream(new JsonHierarchicalStreamDriver() {
            public HierarchicalStreamWriter createWriter(Writer writer) {
                return new JsonWriter(writer, JsonWriter.DROP_ROOT_MODE);
            }
        });
        return xstream.toXML(obj);
    }
    
    
@Transactional
@RequestMapping(value = "/storeDesignations" , method = RequestMethod.POST)     
public ModelAndView store(@RequestParam(value = "json", required = false) String json,HttpServletRequest request) throws JSONException {  
     	
		String jsonc = "{" + json + "}";
		JSONObject jsonObj = new JSONObject(jsonc);
		Designations designations = new Designations();
		
		if (jsonObj.has("designationRandomNumber") && !(jsonObj.getString("designationRandomNumber").isEmpty())){
			designations.setDesignationRandomNumber(jsonObj.getString("designationRandomNumber"));
			}
		
		if (jsonObj.has("designationName") && !(jsonObj.getString("designationName").isEmpty())){
			designations.setDesignationName(jsonObj.getString("designationName"));
		}
		
		if (jsonObj.has("description") && !(jsonObj.getString("description").isEmpty())){
			designations.setDescription(jsonObj.getString("description"));
			}
		
	
	   Session s =  sessionFactory.getCurrentSession();
	   Transaction trans=s.beginTransaction();
	   s.save(designations);
	   trans.commit();
	   
  	   ModelAndView m = new ModelAndView();
  	   m.setViewName("designations");
       return m; 
}  
 
}
