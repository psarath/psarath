package com.payroll.controller;

import javax.servlet.Registration;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.User;


@Controller  
public class RegistrationController {  
	
	
	@Autowired 
	private SessionFactory sessionFactory;   
	
    @RequestMapping("/registration")  
    public ModelAndView Registration(@ModelAttribute User user) {  
    	  
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("registration"); //jsp name
	       return m;  
    }  
    
    @Transactional
    @RequestMapping(value= "/insertregistration" , method = RequestMethod.POST)  
    public ModelAndView insert(@ModelAttribute User user) {  
         
    	   Session s =  sessionFactory.getCurrentSession();
		   Transaction trans=s.beginTransaction();
		   s.saveOrUpdate(user);
		   trans.commit();
		   
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("login");
	       return m; 
    }  
    
    
    
}

