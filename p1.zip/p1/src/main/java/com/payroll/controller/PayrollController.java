package com.payroll.controller;

import java.io.Writer;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.entity.Employee;
import com.payroll.entity.Payroll;
import com.payroll.mail.MailMail;
import com.payroll.pdf.PayrollPdf;
import com.payroll.service.EmployeeService;
import com.payroll.service.PayrollService;

import cucumber.deps.com.thoughtworks.xstream.XStream;
import cucumber.deps.com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import cucumber.deps.com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;
import cucumber.deps.com.thoughtworks.xstream.io.json.JsonWriter;

 
@Controller  
public class PayrollController {  
	
	
	@Autowired 
	private SessionFactory  sessionFactory;
	
	@Autowired
	private PayrollService  payrollService;
	
	@Autowired
	private MailMail mailMail;

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private PayrollPdf payrollPdf;
	
	
	public static DateFormat DF_DMY = new SimpleDateFormat("dd-MM-yyyy");
	 
    @RequestMapping("/payrollList")  
    public ModelAndView payroll(@ModelAttribute Payroll payroll) {  
    	
    	   
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("payrollList");
	       return m; 
    }
	       
	       @RequestMapping(value = "/getpayrollList", method = RequestMethod.POST)
	       public @ResponseBody String payrollList() {  
	       	   String resultJson = null;
	       	   List<Payroll>  payrollList = payrollService.getAllpayroll();
	          	for(Payroll payroll :payrollList){
	          		
	          		if(payroll.getStartDate()!=null){
	          			payroll.setStartDateStr(DF_DMY.format(payroll.getStartDate()));
	    			}
	          		if(payroll.getEndDate()!=null){
	          			payroll.setEndDateStr(DF_DMY.format(payroll.getEndDate()));
	    			}
	          		if(payroll.getCreatedDate()!=null){
	          			payroll.setCreatedDateStr(DF_DMY.format(payroll.getCreatedDate()));
	    			}
	          		if(payroll.getUpdatedDate()!=null){
	          			payroll.setUpdatedDateStr(DF_DMY.format(payroll.getUpdatedDate()));
	    			}
	          	}
	      
	       	   resultJson =  toJSON(payrollList);
	   		   return resultJson;
	       }
	       public String toJSON(Object obj){
	           XStream xstream = new XStream(new JsonHierarchicalStreamDriver() {
	               public HierarchicalStreamWriter createWriter(Writer writer) {
	                   return new JsonWriter(writer, JsonWriter.DROP_ROOT_MODE);
	               }
	           });
	           return xstream.toXML(obj);
	       }
	           
	  

     
    
    @Transactional
    @RequestMapping(value = "/storepayroll", method = RequestMethod.POST)  
    public ModelAndView store(@RequestParam(value = "json", required = false) String json,HttpServletRequest request) throws JSONException, ParseException {  
         
	    	String jsonc = "{" + json + "}";
			JSONObject jsonObj = new JSONObject(jsonc);
			Payroll payroll = new Payroll(); 
			
			DateFormat da = new SimpleDateFormat("mm/dd/yyyy");
			
			if (jsonObj.has("startDate") && !(jsonObj.getString("startDate").isEmpty())){
				payroll.setStartDate(da.parse(jsonObj.getString("startDate")));
			}
   		     
			if (jsonObj.has("endDate") && !(jsonObj.getString("endDate").isEmpty())){
				payroll.setEndDate(da.parse(jsonObj.getString("endDate")));
			}
   		
			if (jsonObj.has("description") && !(jsonObj.getString("description").isEmpty())){
				payroll.setDescription(jsonObj.getString("description"));
			}
			
		    payroll.setCreatedDate(new Date());
			
			if (jsonObj.has("createdBy") && !(jsonObj.getString("createdBy").isEmpty())){
				payroll.setCreatedBy(jsonObj.getString("createdBy"));
			}
			
			payroll.setUpdatedDate(new Date());
			
			
			if (jsonObj.has("updatedBy") && !(jsonObj.getString("updatedBy").isEmpty())){
				payroll.setUpdatedBy(jsonObj.getString("updatedBy"));
			}
    	   org.hibernate.Session s =  sessionFactory.getCurrentSession();
		   Transaction trans=s.beginTransaction();
		   s.save(payroll);
		   trans.commit();
		   
	  	   ModelAndView m = new ModelAndView();
	  	   m.setViewName("payroll");
	       return m; 
        } 
        
    
    
        @Transactional
	    @RequestMapping(value = "/generatePayroll")
	    public @ResponseBody String generatePayroll(@RequestParam (value = "payrollId", required = false)Long payrollId){
        	List<Employee>  empList = employeeService.getAllEmployeeList();
        	
        	for(Employee emp : empList){
        		byte[] payroll =  payrollPdf.generatePdf(emp); 		
        		mailMail.sendMail("tejareddy.bhreddy@gmail.com",
        				emp.getEmailId(),
             		   "Testing123",
             		   "Testing only \n\n Hello Spring Email Sender",payroll);
        	}
        	
        	String resultJson = null;
			return resultJson;
	    	   
	    	   
			
	    }
      
    
    
   }
