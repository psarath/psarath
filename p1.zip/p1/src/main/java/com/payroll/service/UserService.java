package com.payroll.service;

public interface UserService {

}
