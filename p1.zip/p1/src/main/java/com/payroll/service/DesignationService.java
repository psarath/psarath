package com.payroll.service;

import java.util.List;

import com.payroll.entity.Designations;

public interface DesignationService {
	
	

	List<Designations> getAlldesignations();

}
