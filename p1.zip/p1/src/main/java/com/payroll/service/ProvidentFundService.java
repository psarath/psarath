package com.payroll.service;

import com.payroll.entity.ProvidentFund;

public interface ProvidentFundService {
	
	public void storeProvidentFund(ProvidentFund providentFund);

}
