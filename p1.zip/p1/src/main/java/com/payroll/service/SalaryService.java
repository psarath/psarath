package com.payroll.service;

import com.payroll.entity.Salary;

public interface SalaryService {
	
	public void storeSalary(Salary salary); 


}
