package com.payroll.service;

import java.util.List;

import org.apache.poi.ss.formula.functions.Offset;

import com.payroll.entity.Employee;

public interface EmployeeService {
	
	public void storeEmployee(Employee employee);
	
	public List<Employee>  getAllEmployeeList();
	
	
	public List<Employee> getAllEmployeeListWithOffset(String offset);
	
	
	public Employee getEmployeeByEmployeeId(Long employeeId);
	
	public List<Employee> getemployeeListByBusinessUnitID(Long businessUnitID);


	
}
