package com.payroll.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ProvidentFund", catalog = "payroll")
public class ProvidentFund {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PfId", nullable = false)
	private Long pfId;
	
	@Column(name = "PfAmount")
	private String pfAmount;
	
	@Column(name = "PfAccount")
	private String pfAccount;
	
	@ManyToOne
    @JoinColumn(name="Employee", nullable=false )        
    private Employee employee;
	
	@ManyToOne
    @JoinColumn(name="Salary", nullable=false )        
    private Salary salary;
	
	
	@Column(name = "CREATED_DATE")
	private String createdDate;
	
	@Column(name = " CREATED_BY ")
	private String createdBy;
	
	@Column(name = " UPDATED_DATE ")
	private String updatedDate;
	
	@Column(name = " UPDATED_BY ")
	private String updatedBy;

	public Long getPfId() {
		return pfId;
	}

	public void setPfId(Long pfId) {
		this.pfId = pfId;
	}

	public String getPfAmount() {
		return pfAmount;
	}

	public void setPfAmount(String pfAmount) {
		this.pfAmount = pfAmount;
	}

	public String getPfAccount() {
		return pfAccount;
	}

	public void setPfAccount(String pfAccount) {
		this.pfAccount = pfAccount;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Salary getSalary() {
		return salary;
	}

	public void setSalary(Salary salary) {
		this.salary = salary;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	
}
