package com.payroll.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BusinessUnit", catalog = "payroll")
public class BusinessUnit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BusinessUnitID", nullable = false)
	private Long businessUnitID;
	
	@Column(name = "BusinessUnitName")
	private String businessUnitName;
	
	@Column(name = "BusinessUnitRandomNumber")
	private String businessUnitRandomNumber;
	
	@Column(name = "Description")
	private String description;
	
	@Column(name = "CREATED_DATE")
	private Date createdDate;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "UPDATED_DATE")
	private Date updatedDate;
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;

	public Long getBusinessUnitID() {
		return businessUnitID;
	}

	public void setBusinessUnitID(Long businessUnitID) {
		this.businessUnitID = businessUnitID;
	}

	public String getBusinessUnitName() {
		return businessUnitName;
	}

	public void setBusinessUnitName(String businessUnitName) {
		this.businessUnitName = businessUnitName;
	}

	public String getBusinessUnitRandomNumber() {
		return businessUnitRandomNumber;
	}

	public void setBusinessUnitRandomNumber(String businessUnitRandomNumber) {
		this.businessUnitRandomNumber = businessUnitRandomNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setdescription(String string) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
}