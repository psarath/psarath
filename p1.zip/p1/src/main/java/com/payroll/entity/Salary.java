package com.payroll.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Salary", catalog = "payroll")
public class Salary {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SalaryID", nullable = false)
	private Long salaryId;
	
	@Column(name = "Basic")
	private String basic;
	
	@Column(name = "Allowance")
	private Date allowance;
	
	@Column(name = "Tax")
	private String tax;
	
	@Column(name = "GrossSalary")
	private String grossSalary;
	
	@Column(name = "NetSalary")
	private String netSalary;
	
	@Column(name = "Hra")
	private String hra;
	
	@Column(name = "Esi")
	private String esi;
	
	@Column(name = " Esino")
	private String esino;
	
	@Column(name = "ConveyanceAllowance")
	private String conveyanceAllowance;
	
	@Column(name = "MedicalAllowance")
	private String medicalAllowance;
	
	@Column(name = "OtherAllowances")
	private String otherAllowances;
	
	@ManyToOne
    @JoinColumn(name="Employee", nullable=false )        
    private Employee employee;
	
	@Column(name = "CREATED_DATE")
	private String createdDate;
	
	@Column(name = " CREATED_BY ")
	private String createdBy;
	
	@Column(name = " UPDATED_DATE ")
	private String updatedDate;
	
	@Column(name = " UPDATED_BY ")
	private String updatedBy;

	public Long getSalaryId() {
		return salaryId;
	}

	public void setSalaryId(Long salaryId) {
		this.salaryId = salaryId;
	}

	public String getBasic() {
		return basic;
	}

	public void setBasic(String basic) {
		this.basic = basic;
	}

	public Date getAllowance() {
		return allowance;
	}

	public void setAllowance(Date allowance) {
		this.allowance = allowance;
	}

	public String getTax() {
		return tax;
	}

	public void setTax(String tax) {
		this.tax = tax;
	}

	public String getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(String grossSalary) {
		this.grossSalary = grossSalary;
	}

	public String getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(String netSalary) {
		this.netSalary = netSalary;
	}

	public String getHra() {
		return hra;
	}

	public void setHra(String hra) {
		this.hra = hra;
	}

	public String getEsi() {
		return esi;
	}

	public void setEsi(String esi) {
		this.esi = esi;
	}

	public String getEsino() {
		return esino;
	}

	public void setEsino(String esino) {
		this.esino = esino;
	}

	public String getConveyanceAllowance() {
		return conveyanceAllowance;
	}

	public void setConveyanceAllowance(String conveyanceAllowance) {
		this.conveyanceAllowance = conveyanceAllowance;
	}

	public String getMedicalAllowance() {
		return medicalAllowance;
	}

	public void setMedicalAllowance(String medicalAllowance) {
		this.medicalAllowance = medicalAllowance;
	}

	public String getOtherAllowances() {
		return otherAllowances;
	}

	public void setOtherAllowances(String otherAllowances) {
		this.otherAllowances = otherAllowances;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	
}
